---
title: "Concepts: How Forecasts Are Structured"
description: "Introduces how the NWS API organizes forecasts using grids, zones, and linked data."
---

# How Forecasts Are Structured

## Introduction

The NWS API is built on a spatial data model. Forecasts, alerts, and observations aren’t tied directly to latitude and longitude—they’re organized into **grids**, **zones**, and **forecast offices**. Understanding this structure makes the rest of the API far more predictable and helps you design applications that return accurate, location-aware weather data.

This section gives you a high-level overview of that model:

- what spatial building blocks the NWS uses,
- how a geographic point maps to those structures, and
- why this matters when working with any forecast or alert endpoint.

**By the end of this page, you’ll understand how a user’s `lat,lon` becomes the grid and zone resources you use throughout the NWS API.**

## The Big Picture

Every NWS forecast starts with a geographic point—a latitude/longitude pair supplied by your application or your user. The API then resolves that point into three key components:

**1. A forecast office (WFO)** — the local NWS office responsible for producing forecasts for that area.

**2. A forecast grid cell** — a 2.5 km × 2.5 km cell that contains the detailed, location-specific forecast data.

**3. One or more forecast zones** — larger regional areas used for public forecasts, fire weather products, marine forecasts, and alerts.

This spatial model is what shapes the design of the NWS API. **You never request a forecast directly from a coordinate.** Instead, you call `/points/{lat},{lon}`, and the API tells you which grid, which zone, and which office own that location—along with links to the forecast and alert endpoints associated with them.

Once you understand how this mapping works, the API becomes much easier to predict and integrate into your application.

## Conceptual Flow

A location is resolved in the following order:

- **Point** (lat/lon)
- → **Grid** (2.5 km forecast cell)
- → **Zone** (regional forecast or alert area)
- → **Forecast Office** (responsible WFO)

👉**Next:** Learn how to translate coordinates into [Grids](./grids.md) →