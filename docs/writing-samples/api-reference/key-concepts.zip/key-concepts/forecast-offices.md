---
title: "Forecast Offices (WFOs)"
description: "Introduces Weather Forecast Offices (WFOs) and why they matter in the API."
---
# Forecast Offices (WFOs)

Weather Forecast Offices (WFOs) are the regional NWS offices responsible for generating forecasts, maintaining grid data, and issuing alerts for their service area.

When you query `/points/{lat},{lon}`, the API tells you which office covers that location via:

- **cwa** — the office ID (e.g., BUF)
- **forecastOffice** — link to `/offices/{officeId}`
- **gridId** — same as the WFO ID; identifies which grid to use

WFOs matter because they define:

- the grid you’ll request forecasts from
- the zones used for public alerts
- the regional metadata that contextualizes forecast and hazard products

Most apps don’t call office endpoints directly, but WFO IDs appear throughout the API and are essential for navigating gridpoint forecasts.
